def chatbot():
    print("Bot: Hi! I’m a simple rule-based chatbot. Type 'bye' to exit.")

    while True:
        user_input = input("You: ").lower()

        if "hello" in user_input:
            print("Bot: Hello! How can I help you?")
        elif "how are you" in user_input:
            print("Bot: I’m just a bunch of code, but I’m doing fine!")
        elif "your name" in user_input:
            print("Bot: I’m ChatBot 1.0.")
        elif "bye" in user_input:
            print("Bot: Goodbye!")
            break
        else:
            print("Bot: Sorry, I don't understand that.")

chatbot()
